<?php

include_once '../Models/Cliente.php';
class ClienteControllers extends Cliente{
    
    //validar datos del login
    public function ValidarDatosLogin($Email,$Password){

      
        
        $this->Email    =$Email;
        $this->Password =$Password;
        $ClienteCont = $this-> ConsultarCliente();
   
       
       
        if ($ClienteCont =='YES') {
        $_SESSION['error'] = 'Usuario no existe';
        $this->PaginaPrincial();
    }else{

if (password_verify($this->Password,$ClienteCont->contrasena_cliente)) {
$_SESSION['Id']     = $ClienteCont->idcliente;
$_SESSION['Email']  = $ClienteCont->email_cliente;
$_SESSION['Nombre'] = $ClienteCont->nombre_cliente;

unset($_SESSION['error']);
// $this-> PaginaPrincial();
echo $_SESSION['Id'] ;

}else{

$_SESSION['error']= 'La Contraseña es incorrecta';
echo  "mal";

}

         }   

    } 
    
    
    
    
    //registro clientes
    public function ValidarDatos($Email,$Password,$Nombre,$cedula,$edad,$telefono){

        $this->Email    =$Email;
        $this->Password =$Password;
        $this->Nombre   =$Nombre;
        $this->Cedula    =$cedula;
        $this->Edad      =$edad ;  
        $this->Telefono =$telefono;

//validar datos
        // var_dump($Email);
        var_dump($Password);
        // var_dump($Nombre);
        // var_dump($cedula);
        // var_dump($edad);
        // var_dump($telefono);
     
        $cliente =$this-> GuardarCliente();
        
        // if ($cliente =='N') {
        //     $_SESSION['error'] = 'Un error ha ocurrido en su registro intentelo mas tarde';
        //     $this->Redirectlog();
        // }else{
        //     $_SESSION['exito'] = ' Registro exitoso';
        //     $this->Redirectlog();
        // }
        
        }


        public function LogOut(){

  
            unset($_SESSION['Email']);
            session_destroy();
            
            header("location: ../");
        
        
        
        
        
        } 


        public function CerrarSesion(){

  
            unset($_SESSION['Email']);
            session_destroy();
            
            header("location: ../");
        
        
        
        
        
        } 


        public function PaginaPrincial(){

            header("location:../index.php");
            
                }



}






if(isset($_POST['trigger']) && $_POST['trigger'] == 'registro'){

   
    if (isset($_POST['Email'])&&isset($_POST['Password'])&&isset($_POST['Nombre'])&&isset($_POST['Cedula'])&&isset($_POST['Telefono'])&&isset($_POST['Edad'])) {
    $instanceap = new ClienteControllers();
   
   $ValidarEmail = $_POST['Email'];
   $ValidarPassword=$_POST['Password'];
   $ValidarNombre=$_POST['Nombre'];
   $ValidarCedula=$_POST['Cedula'];
   $ValidarTelefono=$_POST['Telefono'];
   $ValidarEdad=$_POST['Edad'];

   
    $instanceap->ValidarDatos($_POST['Email'], $_POST['Password'],$_POST['Nombre'],$_POST['Cedula'],$_POST['Telefono'],$_POST['Edad']);
  
  
  
  
  
  
  
  
    // $instanceap->Redirectlog();

}else{ 

   echo "slaio mal!!";
}



}



if(isset($_POST['trigger']) && $_POST['trigger'] == 'login'){
    if (isset($_POST['Email'])&&isset($_POST['Password'])) {
    $instanceap = new ClienteControllers();
    $instanceap->ValidarDatosLogin($_POST['Email'], $_POST['Password']);
 }else{ 
   echo "slaio mal!!";
}
}



?>